<?php /*Template name: Inicio */
get_header();?>
<div class="main-content">
<?php 
the_content();
?>	
</div>
<?php get_footer(); ?>